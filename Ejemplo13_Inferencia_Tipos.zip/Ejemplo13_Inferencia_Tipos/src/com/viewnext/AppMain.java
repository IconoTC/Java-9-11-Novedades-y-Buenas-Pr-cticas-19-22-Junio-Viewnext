package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;

import com.viewnext.business.ItfzCalculadora;

public class AppMain {
	
	public static void main(String[] args) {
		
		var prueba = 200;
		
		// No se puede aplicar a variables sin inicializar o nulas
		// var sin;
		// var nula = null;
		
		// Cuidado con los arrays
		//var numeros = {1,2,3,4,5};   // ERROR
		var numeros = new int[]{1,2,3,4,5};
		
		// En Java los arrays no son redimensionales
		var numeros2 = new int[10];
		System.arraycopy(numeros, 0, numeros2, 0, numeros.length);
		System.out.println(Arrays.toString(numeros2));
		
		
		// Colecciones
		var lista = new ArrayList<Integer>(Arrays.asList(1,2,3,4));
		var lista2 = new ArrayList<>(Arrays.asList(1,2,3,4));
		var lista3 = new ArrayList<Integer>();
		var lista4 = new ArrayList<>();
		
		
		// Utilizando el bucle for mostrar los numeros del 1 al 10 con inferencia de tipos
		for (var num = 1; num <= 10; num++) {
			System.out.println(num);
		}
		
		// Crear un array de nombres y recorrerlo con inferencia de tipos
		var nombres = new String[] {"Juan", "Maria", "Pedro", "Luis", "Sara"};
		for (var item : nombres) {
			System.out.println(item);
		}
		
		// Tampoco funciona si intento guardar el valor de invocar a un metodo main
		// var respuesta = new AppMain().saludo();
		
		
		// Ejercicio vais a crear los metodos lambda utilizando inferencia de tipos
		ItfzCalculadora suma = (var n1, var n2) -> n1 + n2;
		System.out.println("7 + 3 = " + suma.operacion(7, 3));
		
		ItfzCalculadora resta =  (n1, n2) -> n1 - n2;
		System.out.println("7 - 3 = " + resta.operacion(7, 3));
		
		ItfzCalculadora multiplicacion =  (var n1, var n2) -> n1 * n2;
		System.out.println("7 * 3 = " + multiplicacion.operacion(7, 3));
		
		ItfzCalculadora division =  (n1, n2) -> n1 / n2;
		System.out.println("7 / 3 = " + division.operacion(7, 3));
		
	}
	
	
	public void saludo() {
		System.out.println("Hola");
	}

}




