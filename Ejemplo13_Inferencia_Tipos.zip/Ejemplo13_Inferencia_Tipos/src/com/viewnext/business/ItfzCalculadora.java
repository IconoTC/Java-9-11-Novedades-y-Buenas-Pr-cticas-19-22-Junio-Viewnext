package com.viewnext.business;

// Interface funcional es porque solo tiene un metodo abstracto
public interface ItfzCalculadora {
	
	double operacion(double n1, double n2);

}
