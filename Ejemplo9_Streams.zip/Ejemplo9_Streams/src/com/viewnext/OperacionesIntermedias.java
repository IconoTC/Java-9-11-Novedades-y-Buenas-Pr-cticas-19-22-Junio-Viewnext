package com.viewnext;

import java.util.List;

import com.viewnext.models.Provincia;
import com.viewnext.utils.Utilidad;

public class OperacionesIntermedias {

	public static void main(String[] args) {
		
		List<Provincia> provincias = Utilidad.crearLista();
		
		// Mostrar las provincias que tienen densidad de poblacion superior a 50
		provincias.stream()
			.filter(prov -> prov.getDensidadPoblacion() > 50)
			.map(prov -> prov.getNombre())
			.forEach(System.out::println);
		System.out.println("-------------------------");
		
		
		// Mostrar los dialectos ordenados unicos
		provincias.stream()
			.map(prov -> prov.getDialecto())
			.distinct()
			.sorted()
			.forEach(System.out::println);
		System.out.println("-------------------------");
		
		
		// Mostrar solo las 3 primeras provincias
		provincias.stream()
			.limit(3)
			.forEach(System.out::println);
		System.out.println("-------------------------");
		
		
		// peek -> realiza una operacion especifica y devuelve el elemento al stream
		// Es ideal para pintar resultados intermedios
		provincias.stream()
			.peek(prov -> System.out.println("Procesando " + prov + " ---------"))
			.filter(prov -> prov.getDensidadPoblacion() > 70)
			.peek(prov -> System.out.println("Resultado " + prov + " ---------"))
			.map(prov -> prov.getNombre())
			.forEach(System.out::println);
		System.out.println("-------------------------");

	}

}






