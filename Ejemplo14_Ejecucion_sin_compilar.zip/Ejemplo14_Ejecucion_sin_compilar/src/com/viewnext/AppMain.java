package com.viewnext;

public class AppMain {

	public static void main(String[] args) {
		
		// java /Users/anaisabelvegascaceres/Desktop/Novedades9-11-ViewNext-19-Junio/Ejemplo14_Ejecucion_sin_compilar/src/com/viewnext/AppMain.java
		
		System.out.println("Esto es una prueba de ejecutar sin compilar");

	}

}
