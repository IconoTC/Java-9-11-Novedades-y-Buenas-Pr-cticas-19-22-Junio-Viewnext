package com.viewnext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		List<String> nombres = new ArrayList<>();
		nombres.add("Juan");
		nombres.add("Maria");
		nombres.add("Pedro");
		nombres.add(null);
		
		nombres.remove(0);
		System.out.println(nombres);
		
		// Java 9 permite crear listas inmutables
		// como las tuplas de Python
		List<String> nombres2 = List.of("Juan", "Maria", "Pedro");
		
		// java.lang.UnsupportedOperationException
		//nombres2.add("Pepito");
		//nombres2.remove(0);
		System.out.println(nombres2);
		
		// Las colecciones inmutables se utilizan para valores que no cambian
		List<String> dias = List.of("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo");
		
		
		Set<Integer> numeros = new HashSet<>();
		numeros.add(8);
		numeros.add(new Integer(5));
		numeros.add((int) 9.5);
		numeros.add(Integer.parseInt("12"));
		
		
		// Java 9 permite crear conjuntos inmutables
		Set<String> estados = Set.of("Creada", "Asignada", "En curso", "Resuelta");
		
		// Tanto en listas como conjuntos no se permiten valores nulos
		//Set<String> estados = Set.of("Creada", "Asignada", "En curso", "Resuelta", null);
		
		Map<String, Double> alumnos = new HashMap<>();
		alumnos.put("Jorge", 9.8);
		alumnos.put("Laura", 7.2);
		alumnos.put("Alex", 4.1);
		
		alumnos.remove("Jorge");
		System.out.println(alumnos);
		
		
		// Java 9 permite crear mapas inmutables
		Map<String, Character> diasSemana = Map.of(
				"Lunes", 'L', "Martes",'M', "Miercoles", 'X', "Jueves", 'J',
				   "Viernes",'V', "Sabado", 'S', "Domingo", 'D');
		System.out.println(diasSemana);
		
		System.out.println(alumnos.keySet());   // Nombres de los alumnos
		System.out.println(alumnos.values());   // Solo las notas
		System.out.println(alumnos.entrySet());  // Elementos key=value

	}

}











