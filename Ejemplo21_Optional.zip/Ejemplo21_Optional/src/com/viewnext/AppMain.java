package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		dao.consultarTodos().stream()
			.forEach(System.out::println);
		
		// Buscar un producto que existe
		System.out.println("Encontrado: " + dao.buscarProducto(3).get());
		
		
		// Buscar un producto que NO existe
		
		// Primera forma
		// java.util.NoSuchElementException: No value present
		// System.out.println("No existe: " + dao.buscarProducto(222222).get());
		System.out.println("No existe: " + dao.buscarProducto(222222).orElse(new Producto()));
		
		
		
		// Segunda forma
		Optional<Producto> opProducto = dao.buscarProducto(222222);
		if (opProducto.isPresent()) {
			System.out.println(opProducto.get());
		} else {
			System.out.println("Producto no encontrado");
		}

	}

}
