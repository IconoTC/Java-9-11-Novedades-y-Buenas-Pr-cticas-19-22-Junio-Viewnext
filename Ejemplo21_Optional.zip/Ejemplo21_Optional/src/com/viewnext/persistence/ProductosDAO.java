package com.viewnext.persistence;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.viewnext.models.Producto;

public class ProductosDAO {
	
	// Crear una lista estatica con 5 productos
	private static List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Scanner", 200),
			new Producto(3, "Teclado", 35),
			new Producto(4, "Raton", 22),
			new Producto(5, "Impresora", 87.30)
	);
	
	
	public List<Producto> consultarTodos(){
		return lista;
	}
	
	
	public Optional<Producto> buscarProducto(int id){
		
		for (Producto p : lista) {
			if (id == p.getId()) {
				return Optional.of(p);
			}
		}
		
		// Si no lo encuentra devuelvo el Optional vacio
		return Optional.empty();
	}

}
