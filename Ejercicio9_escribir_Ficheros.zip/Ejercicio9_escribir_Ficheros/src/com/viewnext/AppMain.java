package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.viewnext.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		
		int id = 0;
		String descripcion = "";
		double precio = 0;
		
		Path path = Paths.get("productos.txt");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce id: ");
		try {
			id = sc.nextInt();
		} catch (Exception e) {
			System.out.println("Debe ser numerico, vuelve a introducirlo");
			sc = new Scanner(System.in);
			id = sc.nextInt();
		}
		
		System.out.println("Introduce descripcion: ");
		sc = new Scanner(System.in);
		descripcion = sc.nextLine();
		
		System.out.println("Introduce precio: ");
		try {
			sc = new Scanner(System.in);
			precio = sc.nextDouble();
		} catch (Exception e) {
			System.out.println("Debe ser numerico, vuelve a introducirlo");
			sc = new Scanner(System.in);
			precio = sc.nextDouble();
		}
		
		String cadena = id + "-" + descripcion + "-" + precio;
		
		try {
			Files.writeString(path,  cadena  , StandardOpenOption.APPEND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
