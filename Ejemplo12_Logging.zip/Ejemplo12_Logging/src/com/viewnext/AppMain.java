package com.viewnext;

import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AppMain {

	public static void main(String[] args) {
		
		// El logger es el encargado de enviar los mensajes de log
		// Crear el logger
		Logger logger = Logger.getLogger(AppMain.class.getName());
		
		// Version 1
		logger.log(Level.INFO, "Mensaje de informacion");
		logger.log(Level.WARNING, "Mensaje de aviso");
		logger.log(Level.SEVERE, "Mensaje de error serio");
		
		
		// Version 2
		logger.log(Level.INFO, "Mensaje: {0}", "Ejecutando ...");
		logger.log(Level.WARNING, "Mensaje: {0}", "Aviso ...");
		logger.log(Level.SEVERE, "Mensaje: {0}", "ERROR ...");
		
		
		// Version 3
		logger.log(Level.INFO, "Mensaje: {0} {1}", new Object[] {"param1", "param2"});
		logger.log(Level.WARNING, "Mensaje: {0} {1}", new Object[] {"param1", "param2"});
		logger.log(Level.SEVERE, "Mensaje: {0} {1}", new Object[] {"param1", "param2"});
		
		
		// Version 4
		//logger.log(Level.SEVERE, "Mensaje de error serio", new Exception("Error"));
		
		
		// Version 5
		//Supplier<String> supplier = () -> new String("Pepito");
		Supplier<String> supplier = () -> "Pepito";
		logger.log(Level.SEVERE, new Exception("Error"), supplier);
		
		
		// Version 6
		logger.log(Level.SEVERE, supplier);

	}

}
