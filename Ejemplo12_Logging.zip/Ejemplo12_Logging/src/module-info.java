module com.viewnext.ejemplo12 {
	
	requires java.logging;
	
}