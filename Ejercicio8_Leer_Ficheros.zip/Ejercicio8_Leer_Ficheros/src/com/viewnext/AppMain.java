package com.viewnext;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.viewnext.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		
		Path path = Paths.get("productos.txt");
		List<String> lineas = new ArrayList<String>();
		
		try {
			lineas = Files.readAllLines(path);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		for (String linea : lineas) {
			// split por el -
			String[] datos = linea.split("-");
			
			// eliminar espacios en blanco
			for (var i=0; i < datos.length; i++) {
				datos[i] = datos[i].strip();
			}
			
			// parsear el id a int		
			// parsear el precio a double
			// crear el objeto Producto
			Producto producto = new Producto();
			producto.setId(Integer.parseInt(datos[0]));
			producto.setDescripcion(datos[1]);
			producto.setPrecio(Double.parseDouble(datos[2]));
			
			// mostrar en la consola
			System.out.println(producto);
			
		}

	}

}
