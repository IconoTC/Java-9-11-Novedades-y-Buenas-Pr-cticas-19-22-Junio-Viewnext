package com.viewnext;

public class AppMain {

	public static void main(String[] args) {
		
		Saludo saludo = new Saludo();
		
		System.out.println(saludo.saludar("Pepito"));

	}

}
