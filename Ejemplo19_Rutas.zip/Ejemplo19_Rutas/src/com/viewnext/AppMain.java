package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class AppMain {

	public static void main(String[] args) throws IOException {
		
		// Formas de obtener la ruta del fichero
		Path path = Paths.get("/Users/anaisabelvegascaceres/formula_one.csv");
		Path path2 = Path.of("/Users/anaisabelvegascaceres/formula_one.csv");
		
		// Nombre del fichero
		System.out.println(path.getFileName());
		
		// Ruta del fichero
		System.out.println(path.toAbsolutePath());
		
		// Numero de elementos del path sin incluir la raiz
		System.out.println(path.getNameCount());
		
		
		Path fichero = Paths.get("/Users/anaisabelvegascaceres/Desktop/prueba.txt");
		
		// Borrar el fichero si existe
		Files.deleteIfExists(fichero);
		
		// Crear nuevo fichero
		Files.createFile(fichero);
		
		// Copiar el fichero
		Path destino = Paths.get("/Users/anaisabelvegascaceres/Desktop/prueba2.txt");
		Files.copy(fichero, destino);
		
		// Borrar el fichero original
		Files.delete(fichero);
		
		// Mover fichero
		Path otraUbicacion = Path.of("/Users/anaisabelvegascaceres/Documents/prueba2.txt");
		Files.move(destino, otraUbicacion);
		
		Path directorio = Path.of("/Users/anaisabelvegascaceres/Documents/Pruebas_ViewNext");
		Files.createDirectory(directorio);

	}

}
