package com.viewnext;

import java.util.List;
import java.util.stream.Collectors;

public class AppMain {

	public static void main(String[] args) {
		
		// isBlank()
		System.out.println("Hola".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		
		
		// repeat()
		System.out.println("*".repeat(10));
		System.out.println("-".repeat(20));
		System.out.println("Ja".repeat(5));
		
		
		// strip()
		String nombre = "   Juan    ";
		System.out.println("Hola," + nombre + ".");
		
		// Quita espacios derecha e izquierda
		System.out.println("Hola," + nombre.strip() + ".");
		
		// Quitar espacios de la derecha
		System.out.println("Hola," + nombre.stripTrailing() + ".");
		
		// Quitar espacios de la izquierda
		System.out.println("Hola," + nombre.stripLeading() + ".");
		
		
		// lines()
		String texto = "Hola,\nque\ntal?\nmañana\nes\njueves";
		System.out.println(texto);
		System.out.println(texto.lines().collect(Collectors.toList()));
		
		List<String> lista = texto.lines().collect(Collectors.toList());
		for (String item : lista) {
			System.out.println(item.toUpperCase());
		}

	}

}
