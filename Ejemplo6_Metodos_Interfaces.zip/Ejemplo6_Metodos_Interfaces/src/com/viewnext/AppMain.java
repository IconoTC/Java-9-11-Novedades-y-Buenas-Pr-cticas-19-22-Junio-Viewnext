package com.viewnext;

import com.viewnext.business.ItfzMetodos;
import com.viewnext.business.Metodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Los recursos estaticos no necesitan instancias
		ItfzMetodos.estatico();
		
		ItfzMetodos interfaz = new Metodos();
		
		// Invocamos al metodo default
		interfaz.defecto();
		
		System.out.println(interfaz.procesarTexto("Hola, que tal?"));
	}

}
