module com.viewnext.ejercicio4 {
	
	requires com.viewnext.ejercicio3;
	provides com.viewnext.interfaz.ItfzCalculadora with com.viewnext.business.Calculadora;
	
}