package com.viewnext;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class AppMain {

	public static void main(String[] args) throws Exception {
		
		String url = "https://pokeapi.co/api/v2/pokemon";
		
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		
		// Crear el cliente
		HttpClient cliente = HttpClient.newHttpClient();
		
		
		// El cliente envia la peticion
		HttpResponse<String> respuesta =  cliente.send(request, HttpResponse.BodyHandlers.ofString());
	
		
		// Mostrar la respuesta
		System.out.println(respuesta.body());
		
	}

}
