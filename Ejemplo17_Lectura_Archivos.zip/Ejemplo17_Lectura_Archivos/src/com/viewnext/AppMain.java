package com.viewnext;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		
		String fichero = "datos.txt";
		Path path = Paths.get(fichero);
		String contenido = null;
		
		try {
			contenido = Files.readString(path);
			List<String> lineas = Files.readAllLines(path);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		System.out.println(contenido);

	}

}
