module com.viewnext.ejemplo2 {
	
	// Para poder usar el modulo de otro proyecto, 
	// es necesario agegarlo como dependencia en Build path
	requires com.viewnext.ejemplo1;
}