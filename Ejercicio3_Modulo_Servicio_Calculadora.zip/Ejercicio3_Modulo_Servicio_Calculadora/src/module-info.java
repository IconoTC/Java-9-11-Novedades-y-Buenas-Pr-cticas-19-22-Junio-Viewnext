module com.viewnext.ejercicio3 {
	
	exports com.viewnext.interfaz;
}