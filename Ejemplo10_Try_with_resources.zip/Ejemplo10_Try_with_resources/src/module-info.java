module com.viewnext.ejemplo10 {
	
	requires java.sql;
}