package com.viewnext;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AppMain {

	public static void main(String[] args) throws Exception {
		
		// Antes
		Connection con = null;
		try {
			con = DriverManager.getConnection("", "", "");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		// A partir de Java 9 el try con recursos no necesita el bloque finally
		// Version 1
		try(Connection con2 = DriverManager.getConnection("", "", "")) {
			
			// Cuando llega al final del try cierra la conexion de forma automatica
		} catch (Exception e) {
			// Si se produce excepcion tambien se cierra aqui de forma automatica
		}
		
		
		// Version 2
		Connection con3 = DriverManager.getConnection("", "", "");
		try(con3) {
			
			// Cuando llega al final del try cierra la conexion de forma automatica
		} catch (Exception e) {
			// Si se produce excepcion tambien se cierra aqui de forma automatica
		}

	}

}
