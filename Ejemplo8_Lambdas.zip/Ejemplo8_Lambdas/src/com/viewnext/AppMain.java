package com.viewnext;

import com.viewnext.business.ItfzCalculadora;
import com.viewnext.business.ItfzEjemplo;

public class AppMain {

	public static void main(String[] args) {
		
		ItfzEjemplo lambda1 = (String nombre) -> 
			System.out.println("Hola " + nombre);		
		lambda1.metodo("Anabel");
		
		ItfzEjemplo lambda2 = (nombre) -> 
			System.out.println(nombre.toUpperCase());
		lambda2.metodo("Anabel");
		
		// 4 implementacion con lambda (suma, resta, multiplicacion y division)
		ItfzCalculadora sumar = (double num1, double num2) -> num1 + num2;
		System.out.println("3 + 2 = " + sumar.operacion(3, 2));

		
		ItfzCalculadora restar = (num1, num2) -> num1 - num2;
		System.out.println("3 + 2 = " + restar.operacion(3, 2));
		
		ItfzCalculadora multiplicar = (num1, num2) -> {
			return num1 * num2;
		};
		System.out.println("3 + 2 = " + multiplicar.operacion(3, 2));
	}

}
