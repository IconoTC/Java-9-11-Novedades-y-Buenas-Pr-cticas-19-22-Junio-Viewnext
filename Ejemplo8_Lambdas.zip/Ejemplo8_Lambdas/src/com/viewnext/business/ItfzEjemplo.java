package com.viewnext.business;

public interface ItfzEjemplo {
	
	void metodo(String nombre);

}
