module com.viewnext.ejemplo3 {
	
	exports com.viewnext.interfaz;
}