module com.viewnext.ejercicio2 {
	
	requires com.viewnext.ejercicio1;
	
}